var blocks;
(function (blocks) {
    var logger;
    (function (logger) {
        'use strict';
        angular.module('blocks.logger', []);
    })(logger = blocks.logger || (blocks.logger = {}));
})(blocks || (blocks = {}));
//# sourceMappingURL=logger.module.js.map