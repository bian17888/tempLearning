var app;
(function (app) {
    var widgets;
    (function (widgets) {
        'use strict';
        angular.module('app.widgets', []);
    })(widgets = app.widgets || (app.widgets = {}));
})(app || (app = {}));
//# sourceMappingURL=widgets.module.js.map