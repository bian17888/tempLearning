var blocks;
(function (blocks) {
    var exception;
    (function (exception) {
        'use strict';
        angular.module('blocks.exception', ['blocks.logger']);
    })(exception = blocks.exception || (blocks.exception = {}));
})(blocks || (blocks = {}));
//# sourceMappingURL=exception.module.js.map