namespace blocks.logger {
    'use strict';

    angular.module('blocks.logger', []);
}
