System.config({
    // transpiler: 'typescript',
    // typescriptOptions: {
    //     emitDecoratorMetadata: true,
    //     experimentalDecorators: true
    // }
    // defaultJSExtensions: false, //use defaultJSExtensions = false , this is a bug in es6-module-loader 0.17 and should be fixed in next release

    paths: {
        "rx": "rx"
    }
});
// System.paths = {
//     "main": "main.ts",
//     "tooltip": "tooltip.ts",
//     "mycomponent": "mycomponent.ts",
//     "github.service": "github.service.ts"
// };
