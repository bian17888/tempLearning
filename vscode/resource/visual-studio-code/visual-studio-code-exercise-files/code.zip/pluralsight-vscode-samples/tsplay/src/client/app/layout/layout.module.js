var app;
(function (app) {
    var layout;
    (function (layout) {
        'use strict';
        angular.module('app.layout', ['app.core']);
    })(layout = app.layout || (app.layout = {}));
})(app || (app = {}));
//# sourceMappingURL=layout.module.js.map