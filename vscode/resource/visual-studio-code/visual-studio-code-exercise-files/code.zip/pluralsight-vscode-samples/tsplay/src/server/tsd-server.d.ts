/// <reference path="../../typings/body-parser/body-parser.d.ts" />
/// <reference path="../../typings/chai/chai.d.ts" />
/// <reference path="../../typings/express/express.d.ts" />
/// <reference path="../../typings/mocha/mocha.d.ts" />
/// <reference path="../../typings/morgan/morgan.d.ts" />
/// <reference path="../../typings/node/node.d.ts" />
/// <reference path="../../typings/serve-favicon/serve-favicon.d.ts" />
/// <reference path="../../typings/sinon/sinon.d.ts" />
