var app;
(function (app) {
    var admin;
    (function (admin) {
        'use strict';
        angular.module('app.admin', [
            'app.core',
            'app.widgets'
        ]);
    })(admin = app.admin || (app.admin = {}));
})(app || (app = {}));
//# sourceMappingURL=admin.module.js.map