var blocks;
(function (blocks) {
    var router;
    (function (router) {
        'use strict';
        angular.module('blocks.router', []);
    })(router = blocks.router || (blocks.router = {}));
})(blocks || (blocks = {}));
//# sourceMappingURL=router-helper.module.js.map