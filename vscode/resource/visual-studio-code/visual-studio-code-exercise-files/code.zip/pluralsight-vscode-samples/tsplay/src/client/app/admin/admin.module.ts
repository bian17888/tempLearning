namespace app.admin {
    'use strict';

    angular.module('app.admin', [
        'app.core',
        'app.widgets'
      ]);
}
