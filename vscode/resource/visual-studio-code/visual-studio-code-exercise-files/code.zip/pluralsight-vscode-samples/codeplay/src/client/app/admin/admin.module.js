(function () {
    'use strict';

    angular.module('app.admin', [
        'app.core',
        'app.widgets'
      ]);

})();
