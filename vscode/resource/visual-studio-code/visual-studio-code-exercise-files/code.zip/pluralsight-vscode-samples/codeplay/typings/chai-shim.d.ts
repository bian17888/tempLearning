/// <reference path="chai/chai.d.ts" />
declare var expect: Chai.ExpectStatic;